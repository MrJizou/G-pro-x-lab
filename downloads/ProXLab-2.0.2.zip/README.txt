PRO X Lab 2.0.2 — read-only connection diagnostics.

Extract fully and run ProXLab.exe without administrator rights. Read SECURITY.md. This application never writes firmware.
